<?php
echo  '<nav class="navbar navbar-dark bg-dark navbar-expand-lg fixed-top">
        <a class="navbar-brand" href="dataentry.php">KriparamJi</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarsExample">
        <ul class="navbar-nav mr-auto">
            <li class="nav-item">
            <a class="nav-link" href="dataentry.php">New Entry</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="display.php">Record</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="logout.php">Logout</a>
          </li>
          
        </ul>
      </div>
    </nav>';
?>