<?php    
$servername        = "localhost";
$dbname      = "u614119281_datadb";
$username = "u614119281_admin";
$password = "SuperStrongPassword2022";
?>
